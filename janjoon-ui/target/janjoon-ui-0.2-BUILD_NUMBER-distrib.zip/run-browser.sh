#!/bin/bash
sleep 10
nohup gnome-www-browser http://localhost:8080 &
